import ep1
from decimal import Decimal

def lamba():
    n=int(input('Escolha o valor de N: '))
    m=int(input('Escolha o valor de M: '))
    lmbda=(1/m)/(1/n)**2
    print(lmbda)

def matriz():
    u = []
    conta=[]
    for i in range(5):
        if i==0 or i==5:
            conta.append([0]*5)
    print(u)

#def integra ():
#    import scipy
#    u=10*t*(x**2)*(x-1)
#    v=scipy.integrate(u)
#    print(v)

def notacao(n):
    print(f'{n:.2e}')

def integrais(x, n, lmbda, b, a):
    teste=int(input("1- para delta t = delta x: \n2- para m=n²/lambda: "))
    if teste ==1:
        t=ep1.fazt(n)
    elif teste ==2:
        m = ((n**2) / lmbda) - 1   # Tirado de (27)
        t=ep1.fazt(m)
    else:
        print("opcao invalida")
    if b == 1:
        ep1.metodo11 (x,t,a)
    elif b == 2:
        ep1.euler (x,t,a)
    elif b == 3:
        ep1.crank (x,t,a)

def main():
    a=int(input('1-Calcula lamba\n2-Faz Matriz\n3-Integra\
        \n4-Tarefa 1_A Integrais\n5-Notacao cientifica\
        \nQual deseja testar? - '))
    if a==1:
        lamba()
    elif a==2:
        matriz()
    #elif a==3:
    #    integra()
    elif a==4:
        b = 0
        l = 0
        v=[10, 20, 40, 80, 160, 320, 640]
        b = int(input("\n1 - Teste do metodo 11\
                \n2 - Euler Implicito\
                \n3 - Crank Nicolson\
                \nQual teste deseja rodar? - "))
        c = int(input("\nSelecione a função f(t,x) desejada:\
                \n1: f(t,x) = 10x²(x−1)−60xt+ 20t\
                \n2: f(t,x) = 10cos(10t)x²(1−x)²−(1 +sin(10t))(12x²−12x+ 2)\
                \n3: f(t,x) = 25t²e^(t-x) cos(5tx) - 10te^(t-x) sen(5tx) - 5xe^(t-x) sen(5tx)\
                \n4: f(t,x) = 10000(1-2t²)N (p = 0.25 e gh cte):  "))
        for i in v:
            x = ep1.fazx(i)

            l=float(input("\nLambda (0.25 ou 0.5 ou 0.51) = "))
            
            integrais(x, i, l, b, c)

        
    elif a==5:
        b = Decimal(input("Digite o numero: "))
        notacao(b)

if __name__ == "__main__":
    main()


# a=int(input("Selecione a f desejada:\n1: f(t,x) = 10x²(x−1)−60xt+ 20t\n\
# 2: f(t,x) = 10cos(10t)x²(1−x)²−(1 +sin(10t))(12x²−12x+ 2): "))

# if a==1:
#                     f=10*x[i]**2 *(x[i]-1)- 60*x[i]*t[k]+ 20*t[k]
#                 elif a==2:
#                     f=10*math.cos(10*t[k])*(x[i]**2)*((1-x[i])**2)-(1+math.sin(10*t[k]))(12*(x[i]**2)-12*x[i]+ 2)
#                 else:
#                     print('f(t,x) invalida')
#                     break